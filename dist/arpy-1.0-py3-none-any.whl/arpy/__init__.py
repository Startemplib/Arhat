# 初始化包时的一些默认设置
print("Breaking through to the Empyrean.")

# 导入函数
from visual import vnm
